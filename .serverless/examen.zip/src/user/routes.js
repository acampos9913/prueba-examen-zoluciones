const express = require('express');
const axios = require("axios")

const AWS = require('aws-sdk');
const sls = require('serverless-http');
const cors = require('cors');

const bodyParser = require('body-parser');

const USERS_TABLE = process.env.USERS_TABLE;
const dynamoDb = new AWS.DynamoDB.DocumentClient();

const app = express();
app.use(cors());
app.use(bodyParser.json());

const routes = express.Router({
    mergeParams: true
});

routes.get('/api/getswapi', (req, res) => {
    axios.get("https://swapi.py4e.com/api/films/")
    .then(function(response) {
      res.status(200).json(response.data)
    }).catch(function(error) {
      res.json("Error occured!")
    })
});

routes.get('/users/:userId', function (req, res) {
    const params = {
      TableName: USERS_TABLE,
      Key: {
        userId: req.params.userId,
      },
    }
  dynamoDb.get(params, (error, result) => {
      if (error) {
        console.log(error);
        res.status(400).json({ error: `Could not get user ${userId}` });
      }
      if (result.Item) {
        const {userId, name} = result.Item;
        res.json({ userId, name });
      } else {
        res.status(404).json({ error: `User ${userId} not found` });
      }
    });
  });

routes.post('/users', function (req, res) {
    const { userId, name } = req.body;
    const params = {
        TableName: USERS_TABLE,
        Item: {
            userId: userId,
            name: name,
        },
        };
    dynamoDb.put(params, (error) => {
        if (error) {
            console.log(error);
            res.status(400).json({ error: `Could not create user ${userId}` });
        }
        console.log(userId)
        res.json({ userId, name });
        
        });
  });

module.exports = {
    routes,
};